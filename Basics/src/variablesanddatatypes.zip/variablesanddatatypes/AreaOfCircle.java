package variablesanddatatypes;
/*areaof circle=pi*r*r ;
 pi=3.14
 * */
public class AreaOfCircle 
{

	public static void main(String[] args) 
	{
		int radius=23;
		double area=3.14*radius*radius;
		System.out.println("The Area of Circle is=:"+area);
		                   //String+area=

	}

}
