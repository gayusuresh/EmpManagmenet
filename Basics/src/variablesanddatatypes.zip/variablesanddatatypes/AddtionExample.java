package variablesanddatatypes;

public class AddtionExample 
{

	public static void main(String[] args)
	{
		int num1=10,num2=12;
		
		int result=num1+num2;
	   System.out.println(result);
		

	}

}
