package variablesanddatatypes;
/* Areaof rectngale=length*width;
 * 
 */
public class AreaOfRectangle {

	public static void main(String[] args) {
		int length=67,width=89;
		double areaofRectangle=length*width;
		System.out.println("The Area Of Rectangle=:"+areaofRectangle);

	}

}
