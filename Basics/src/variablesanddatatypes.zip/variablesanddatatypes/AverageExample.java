package variablesanddatatypes;

public class AverageExample {

	public static void main(String[] args)
	{
		//example of average
		int num1=7;
		int num2=8;
		int num3=10;
		int total=num1+num2+num3;
		double average=total/3;
		System.out.println("The Average value is=:"+average);

	}

}
